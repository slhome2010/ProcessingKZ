<?php
// Text
$_['text_title'] = '<b>Visa, MasterCard, Maestro</b> <b style="color: #003F62;"> (Processing</b><span style="color: #39B54A;">.kz)</span>';
$_['text_note'] = 'Вы будете переадресованы на сайт платежной системы <b style="color: #003F62;"> Processing</b><span style="color: #39B54A;">.kz</span> Народного Банка Казахстана <br/> Заказ поступит в обработку после поступления средств на наш счет.';
?>